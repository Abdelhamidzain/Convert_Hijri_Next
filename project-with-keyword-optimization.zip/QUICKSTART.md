# 🚀 البدء السريع - محول التاريخ الهجري (Next.js)

تم تحويل المشروع بنجاح من React + Vite إلى Next.js 14!

## ⚡ ابدأ في 3 خطوات

### 1️⃣ فك الضغط والتثبيت
```bash
# فك ضغط الملف
unzip convert-hijri-nextjs.zip
cd convert-hijri-nextjs

# تثبيت التبعيات (اختر واحدة)
npm install
# أو
yarn install
# أو
pnpm install
```

### 2️⃣ إعداد البيئة
```bash
# نسخ ملف البيئة
cp .env.example .env.local

# عدّل .env.local (اختياري)
# NEXT_PUBLIC_SITE_URL=https://your-domain.com
```

### 3️⃣ تشغيل المشروع
```bash
# للتطوير
npm run dev

# افتح المتصفح على
# http://localhost:3000
```

## 📚 الوثائق المتوفرة

- **`README.md`** - دليل شامل للمشروع
- **`MIGRATION_GUIDE.md`** - دليل التحويل التفصيلي
- **`SUMMARY.md`** - ملخص سريع لما تم إنجازه
- **`CHANGELOG.md`** - سجل التغييرات

## ⚠️ ملاحظات مهمة

### المكونات التي تحتاج `'use client'`
بعض المكونات قد تحتاج إضافة `'use client'` في أول السطر إذا كانت تستخدم:
- React hooks (`useState`, `useEffect`, etc.)
- Event handlers (`onClick`, `onChange`, etc.)
- Browser APIs

**مثال:**
```tsx
'use client'

import { useState } from 'react'

export default function MyComponent() {
  const [count, setCount] = useState(0)
  // ...
}
```

### اختبار شامل
قبل النشر للإنتاج:
1. اختبر جميع الصفحات
2. اختبر جميع الروابط
3. افحص Console للأخطاء
4. شغّل `npm run build` للتأكد

## 🚢 النشر

### Vercel (موصى به - مجاني)
```bash
# ادفع للـ GitHub أولاً
git init
git add .
git commit -m "Initial commit"
git push

# ثم على vercel.com:
# 1. استورد من GitHub
# 2. Vercel ستكتشف Next.js تلقائياً
# 3. انقر Deploy!
```

### بدائل أخرى
- Netlify
- Railway
- AWS Amplify
- أي خادم Node.js

## 🆘 مشاكل شائعة وحلولها

**المشكلة:** "useParams is not defined"
```bash
# الحل: أضف 'use client' في أول الملف
```

**المشكلة:** Build errors
```bash
# الحل: تأكد من تثبيت جميع التبعيات
npm install
```

**المشكلة:** Port 3000 مستخدم
```bash
# الحل: استخدم port آخر
npm run dev -- -p 3001
```

## 📞 تحتاج مساعدة؟

1. راجع `MIGRATION_GUIDE.md` للتفاصيل
2. راجع [Next.js Docs](https://nextjs.org/docs)
3. ابحث في [Next.js GitHub](https://github.com/vercel/next.js)

## ✅ نجح التشغيل؟

إذا نجح المشروع في التشغيل بدون أخطاء، مبروك! 🎉

الآن يمكنك:
- تخصيص المحتوى حسب حاجتك
- إضافة ميزات جديدة
- النشر للإنتاج

---

**إصدار Next.js:** 14.x
**تاريخ التحويل:** 11 ديسمبر 2024
