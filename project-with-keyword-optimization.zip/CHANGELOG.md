# Changelog

تسجيل جميع التغييرات المهمة في المشروع.

## [2.0.0] - تحويل إلى Next.js - 2024-12-11

### إضافات 🎉
- تم التحويل الكامل من React + Vite إلى Next.js 14
- إضافة App Router لتوجيه أفضل وأداء محسّن
- إضافة Server Components للصفحات الثابتة
- إضافة Next.js Metadata API لـ SEO محسّن
- إضافة دعم كامل لـ TypeScript
- إضافة Automatic Code Splitting
- إضافة Image Optimization مع next/image
- إضافة Font Optimization

### تغييرات 🔄
- استبدال React Router بـ Next.js Router
- استبدال Vite بـ Next.js build system
- تحديث جميع المكونات للتوافق مع Next.js
- تحديث Navbar لاستخدام next/link و usePathname
- تحديث NavLink كمكون مخصص لـ Next.js
- تحديث InternalLinks لاستخدام next/link
- تحويل جميع الصفحات إلى App Router structure

### إزالات ❌
- إزالة react-router-dom
- إزالة Vite configuration
- إزالة مكتبات غير ضرورية

### إصلاحات 🐛
- إصلاح مشاكل التوجيه
- إصلاح مشاكل الـ hydration
- إصلاح مشاكل الـ SEO metadata

### تحسينات ⚡
- تحسين الأداء بشكل عام
- تحسين SEO
- تحسين تجربة المستخدم
- تحسين وقت التحميل الأولي

## [1.0.0] - الإصدار الأصلي

### الميزات
- محول التاريخ الهجري والميلادي
- حساب العمر بالهجري والميلادي
- عرض التقويم الهجري
- تاريخ اليوم في مدن مختلفة
- واجهة عربية كاملة
- دعم Shadcn/ui components
- دعم Tailwind CSS
