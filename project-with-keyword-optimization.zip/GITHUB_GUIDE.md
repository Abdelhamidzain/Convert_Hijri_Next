# 📤 دليل رفع المشروع على GitHub للمبتدئين

دليل سهل ومبسط لرفع مشروع Next.js على GitHub بدون خبرة برمجية!

---

## 🎯 الطريقة الأولى: عن طريق الموقع (الأسهل - بدون أوامر!)

### الخطوة 1️⃣: إنشاء حساب GitHub

1. اذهب إلى [github.com](https://github.com)
2. اضغط على **Sign up** (التسجيل)
3. أدخل:
   - البريد الإلكتروني
   - كلمة المرور (قوية!)
   - اسم المستخدم (اختر اسم مناسب)
4. اتبع خطوات التحقق
5. فعّل حسابك من البريد الإلكتروني

---

### الخطوة 2️⃣: إنشاء Repository جديد

1. بعد تسجيل الدخول، اضغط على علامة **+** في الأعلى
2. اختر **New repository**
3. املأ المعلومات:
   - **Repository name**: `convert-hijri-nextjs` (أو أي اسم تريده)
   - **Description**: محول التاريخ الهجري - Next.js
   - اختر **Public** (عام) أو **Private** (خاص)
   - ✅ **لا تختر** "Add a README file" (احذف العلامة)
   - ✅ **لا تختر** "Add .gitignore" (احذف العلامة)
4. اضغط **Create repository**

---

### الخطوة 3️⃣: رفع الملفات (طريقة سهلة)

الآن أنت في صفحة الـ repository الفارغة:

#### أ. فك ضغط المشروع أولاً
1. فك ضغط ملف `convert-hijri-nextjs.zip`
2. ستحصل على مجلد `convert-hijri-nextjs`

#### ب. رفع الملفات عبر الموقع

**الطريقة 1: رفع كامل المجلد**
1. في صفحة GitHub، اضغط **uploading an existing file**
2. اسحب مجلد `convert-hijri-nextjs` بالكامل إلى الصفحة
3. أو اضغط **choose your files** واختر جميع الملفات من داخل المجلد
4. انتظر حتى يتم رفع جميع الملفات
5. في الأسفل، اكتب رسالة: `Initial commit - تحويل المشروع إلى Next.js`
6. اضغط **Commit changes**

⚠️ **ملاحظة**: قد تحتاج لرفع الملفات على دفعات إذا كان حجمها كبيراً

---

## 🖥️ الطريقة الثانية: عن طريق Git (للمحترفين قليلاً)

هذه الطريقة تحتاج استخدام Terminal/Command Prompt، لكنها أسرع وأفضل.

### تثبيت Git أولاً

#### على Windows:
1. حمّل Git من [git-scm.com](https://git-scm.com/download/win)
2. ثبّته (اضغط Next في كل شيء)
3. افتح **Git Bash** من قائمة ابدأ

#### على Mac:
```bash
# افتح Terminal واكتب:
git --version
# إذا لم يكن مثبتاً، سيطلب منك تثبيته
```

#### على Linux:
```bash
sudo apt-get install git
```

---

### خطوات الرفع بـ Git

#### 1. افتح Terminal أو Git Bash

#### 2. اذهب إلى مجلد المشروع
```bash
cd Desktop/convert-hijri-nextjs
# غيّر المسار حسب مكان المجلد عندك
```

#### 3. ابدأ Git في المشروع
```bash
git init
```

#### 4. أضف جميع الملفات
```bash
git add .
```

#### 5. اعمل Commit أول
```bash
git commit -m "Initial commit - تحويل المشروع إلى Next.js"
```

#### 6. اربط المشروع بـ GitHub
```bash
# غيّر YOUR-USERNAME باسم مستخدمك في GitHub
# غيّر convert-hijri-nextjs باسم الـ repository إذا كان مختلفاً
git remote add origin https://github.com/YOUR-USERNAME/convert-hijri-nextjs.git
```

**مثال:**
```bash
git remote add origin https://github.com/Abdelhamidzain/convert-hijri-nextjs.git
```

#### 7. ارفع الملفات
```bash
git branch -M main
git push -u origin main
```

#### 8. أدخل بيانات الدخول
- اسم المستخدم في GitHub
- **كلمة المرور**: استخدم **Personal Access Token** (شرحه أدناه)

---

### 🔑 إنشاء Personal Access Token

GitHub لا يقبل كلمة المرور العادية، تحتاج Token:

1. اذهب إلى [github.com/settings/tokens](https://github.com/settings/tokens)
2. اضغط **Generate new token** → **Generate new token (classic)**
3. اكتب اسم للـ Token: `Convert Hijri Project`
4. اختر Expiration: **No expiration** (أو 90 days)
5. اختر Scopes:
   - ✅ **repo** (ضع علامة عليه)
6. اضغط **Generate token**
7. **📋 انسخ الـ Token فوراً** (لن تراه مرة أخرى!)
8. استخدمه بدل كلمة المرور عند الـ push

---

## 🎉 تم! المشروع على GitHub

بعد رفع المشروع، اذهب إلى:
```
https://github.com/YOUR-USERNAME/convert-hijri-nextjs
```

ستجد جميع ملفاتك هناك! 🚀

---

## 🚀 الخطوة التالية: النشر على Vercel (مجاناً!)

الآن المشروع على GitHub، يمكنك نشره على الإنترنت مجاناً:

### 1. اذهب إلى [vercel.com](https://vercel.com)
2. اضغط **Sign Up** ثم اختر **Continue with GitHub**
3. سجّل الدخول بحساب GitHub
4. في Dashboard، اضغط **Add New** → **Project**
5. اختر repository: `convert-hijri-nextjs`
6. اضغط **Import**
7. في إعدادات المشروع:
   - **Framework Preset**: Next.js (سيتم اكتشافه تلقائياً)
   - **Root Directory**: ./
   - **Build Command**: `npm run build`
   - **Output Directory**: .next
8. في **Environment Variables** (اختياري):
   - اضغ **Add**
   - Key: `NEXT_PUBLIC_SITE_URL`
   - Value: `https://your-domain.vercel.app` (سيتم تحديثه لاحقاً)
9. اضغط **Deploy**

### انتظر 2-3 دقائق... ✨

بعدها ستحصل على رابط المشروع المباشر، مثل:
```
https://convert-hijri-nextjs.vercel.app
```

🎊 **مبروك! مشروعك الآن على الإنترنت!**

---

## 🔄 تحديث المشروع لاحقاً

### إذا استخدمت الطريقة الأولى (الموقع):
1. افتح repository على GitHub
2. اضغط **Add file** → **Upload files**
3. ارفع الملفات الجديدة أو المُحدّثة
4. اكتب رسالة التحديث
5. اضغ **Commit changes**

### إذا استخدمت Git:
```bash
# بعد تعديل الملفات
git add .
git commit -m "وصف التحديث"
git push
```

**Vercel سيقوم بالتحديث تلقائياً!** 🎯

---

## ❓ مشاكل شائعة وحلولها

### المشكلة: "Permission denied"
**الحل**: تأكد من صحة الـ Token أو اسم المستخدم

### المشكلة: "Repository not found"
**الحل**: تأكد من اسم الـ repository صحيح في الأمر

### المشكلة: Build failed على Vercel
**الحل**: 
1. تأكد من وجود ملف `package.json`
2. تأكد من وجود ملف `next.config.js`
3. راجع Logs في Vercel لمعرفة الخطأ

### المشكلة: "fatal: not a git repository"
**الحل**: تأكد أنك في مجلد المشروع الصحيح، ونفّذ `git init`

---

## 📚 موارد إضافية

- [دليل GitHub للمبتدئين](https://docs.github.com/en/get-started)
- [دليل Vercel](https://vercel.com/docs)
- [دليل Git الأساسي](https://git-scm.com/book/ar/v2)

---

## 🆘 تحتاج مساعدة؟

إذا واجهت أي مشكلة:
1. ابحث عن الخطأ في Google
2. اسأل في [Stack Overflow](https://stackoverflow.com)
3. راجع [GitHub Docs](https://docs.github.com)

---

## ✅ قائمة التحقق النهائية

- [ ] تم إنشاء حساب GitHub
- [ ] تم إنشاء repository
- [ ] تم رفع جميع الملفات
- [ ] المشروع يظهر على GitHub
- [ ] (اختياري) تم النشر على Vercel
- [ ] الموقع يعمل بشكل صحيح

---

**مبروك! أصبح لديك مشروع Next.js على GitHub! 🎉**

الآن يمكنك مشاركة رابط GitHub أو رابط Vercel مع أي شخص!
