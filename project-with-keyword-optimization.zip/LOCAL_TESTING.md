# 🧪 دليل الاختبار المحلي - خطوة بخطوة

دليل مبسط لاختبار المشروع على جهازك قبل رفعه!

---

## 📋 المتطلبات الأساسية

قبل البدء، تأكد من تثبيت:

### 1️⃣ Node.js (ضروري!)

#### على Windows:
1. اذهب إلى: https://nodejs.org
2. حمّل النسخة **LTS** (الموصى بها)
3. شغّل الملف المُحمّل
4. اضغط "Next" في كل شيء حتى ينتهي التثبيت

#### على Mac:
```bash
# استخدم Homebrew
brew install node
```

#### على Linux:
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install nodejs npm

# أو استخدم nvm (موصى به)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
nvm install --lts
```

#### التحقق من التثبيت:
افتح Terminal أو Command Prompt واكتب:
```bash
node --version
# يجب أن يظهر: v18.x.x أو أحدث

npm --version
# يجب أن يظهر: 9.x.x أو أحدث
```

---

## 🚀 الخطوات (5 دقائق فقط!)

### الخطوة 1: فك ضغط المشروع

```
1. فك ضغط ملف convert-hijri-nextjs.zip
2. ضعه في مكان سهل (مثل: Desktop أو Documents)
```

---

### الخطوة 2: فتح Terminal/Command Prompt

#### على Windows:
```
الطريقة 1 (سهلة):
1. افتح مجلد المشروع
2. اضغط Shift + زر الفأرة الأيمن في المجلد
3. اختر "Open PowerShell window here"

الطريقة 2:
1. اضغط Win + R
2. اكتب: cmd
3. اضغط Enter
```

#### على Mac:
```
الطريقة 1 (سهلة):
1. افتح Finder
2. اذهب للمجلد
3. Services → New Terminal at Folder

الطريقة 2:
1. افتح Terminal
2. اكتب: cd
3. اسحب المجلد على Terminal
4. اضغط Enter
```

#### على Linux:
```
الطريقة 1:
1. افتح File Manager
2. اذهب للمجلد
3. زر الفأرة الأيمن → Open in Terminal

الطريقة 2:
1. افتح Terminal
2. استخدم cd للذهاب للمجلد
```

---

### الخطوة 3: الذهاب لمجلد المشروع

في Terminal/Command Prompt:

#### إذا كان المشروع على Desktop:
```bash
# Windows
cd Desktop\convert-hijri-nextjs

# Mac/Linux
cd Desktop/convert-hijri-nextjs
```

#### إذا كان في مكان آخر:
```bash
# Windows
cd C:\path\to\convert-hijri-nextjs

# Mac/Linux
cd /path/to/convert-hijri-nextjs
```

💡 **نصيحة:** يمكنك كتابة `cd ` ثم سحب المجلد على Terminal!

---

### الخطوة 4: تثبيت التبعيات (أول مرة فقط)

```bash
npm install
```

**انتظر...** ⏳

سيبدأ تنزيل جميع الحزم المطلوبة (حوالي 2-3 دقائق)

#### ما سيحدث:
```
npm WARN deprecated ...
⠴ reify:fsevents: timing reifyNode:node_modules/fsevents
...
added 245 packages, and audited 246 packages in 2m

found 0 vulnerabilities
```

✅ إذا شفت "found 0 vulnerabilities" أو رسالة مشابهة → تمام!

❌ إذا ظهر خطأ:
- جرّب: `npm install --legacy-peer-deps`
- أو: احذف `node_modules` وجرّب مرة ثانية

---

### الخطوة 5: البناء (Build)

```bash
npm run build
```

**انتظر...** ⏳ (1-2 دقيقة)

#### البناء الناجح يبدو كذا:
```
  ▲ Next.js 14.2.33

   Creating an optimized production build ...
 ✓ Compiled successfully
 ✓ Linting and checking validity of types
 ✓ Collecting page data
 ✓ Generating static pages (15/15)
 ✓ Collecting build traces
 ✓ Finalizing page optimization

Route (app)                              Size     First Load JS
┌ ○ /                                    5 kB        87.1 kB
├ ○ /date/today                          1.37 kB     88.4 kB
└ ○ /calendar/[year]                     1.21 kB     88.2 kB

○  (Static)  prerendered as static content

✓ Build completed successfully
```

🎉 **إذا شفت "Build completed successfully"** → مبروك! المشروع جاهز!

---

### الخطوة 6: اختبار المشروع محلياً (اختياري)

```bash
npm run start
```

#### افتح المتصفح:
```
http://localhost:3000
```

✅ إذا شفت الموقع يعمل → ممتاز! كل شيء تمام!

**للإيقاف:** اضغط `Ctrl + C` في Terminal

---

## 🎯 الأوامر المهمة

### للتطوير (مع Hot Reload):
```bash
npm run dev
```
الموقع سيفتح على: http://localhost:3000
أي تغيير يحصل تلقائياً!

### للبناء:
```bash
npm run build
```
يبني المشروع للإنتاج

### لتشغيل البناء:
```bash
npm run start
```
يشغل النسخة المبنية

### للتحقق من الأخطاء:
```bash
npm run lint
```
يفحص الكود للأخطاء

---

## ❌ مشاكل شائعة وحلولها

### المشكلة 1: "command not found: npm"
**السبب:** Node.js غير مثبت
**الحل:** ثبت Node.js من nodejs.org

---

### المشكلة 2: "EACCES: permission denied"
**السبب:** صلاحيات
**الحل (Mac/Linux):**
```bash
sudo npm install
```
**الحل (Windows):** شغل Command Prompt كـ Administrator

---

### المشكلة 3: "Port 3000 already in use"
**السبب:** البورت مشغول
**الحل:** استخدم بورت آخر:
```bash
npm run dev -- -p 3001
```

---

### المشكلة 4: Build Errors
**الحل:**
```bash
# احذف كل شيء وابدأ من جديد
rm -rf node_modules .next
npm install
npm run build
```

---

### المشكلة 5: "Module not found"
**السبب:** مكتبة ناقصة
**الحل:**
```bash
npm install --force
```

---

### المشكلة 6: "Cannot find module 'next'"
**السبب:** التثبيت غير مكتمل
**الحل:**
```bash
npm install next react react-dom
```

---

## 📊 فهم Output البناء

عند البناء الناجح، ستشوف:

```
Route (app)                              Size     First Load JS
┌ ○ /                                    5 kB        87.1 kB
├ ○ /date/today                          1.37 kB     88.4 kB
└ ○ /calendar/[year]                     1.21 kB     88.2 kB
```

### الرموز:
- **○** (Static): صفحة ثابتة - الأسرع
- **λ** (Server): صفحة تُنشأ على الخادم
- **ƒ** (Dynamic): صفحة ديناميكية

### الأحجام:
- **Size**: حجم الصفحة نفسها
- **First Load JS**: إجمالي JavaScript للتحميل الأول

✅ الأصغر = الأفضل!

---

## 🎓 نصائح إضافية

### 1. استخدم Visual Studio Code
- سهل جداً للتعديل
- يحتوي على Terminal مدمج
- حمّل من: https://code.microsoft.com

### 2. افتح المشروع في VS Code:
```bash
code .
```

### 3. Extensions مفيدة:
- ESLint
- Prettier
- Tailwind CSS IntelliSense

### 4. شغّل `npm run dev` أثناء التعديل
- التغييرات تظهر فوراً
- يظهر الأخطاء مباشرة

---

## ✅ قائمة التحقق النهائية

قبل الرفع على GitHub:

- [ ] `npm install` نجح بدون أخطاء
- [ ] `npm run build` نجح بدون أخطاء
- [ ] لا توجد أخطاء في Console
- [ ] الموقع يعمل على `localhost:3000`
- [ ] جربت الصفحات المهمة (الرئيسية، تحويل التاريخ، إلخ)

---

## 🚀 الخطوة التالية

بعد نجاح البناء:

1. ✅ **احفظ التغييرات على GitHub**
   ```bash
   git add .
   git commit -m "تم اختبار المشروع محلياً"
   git push
   ```

2. ✅ **Deploy على Netlify/Vercel**
   - سيعمل تلقائياً بعد الـ push!

---

## 🎉 مبروك!

إذا وصلت هنا ومشى كل شيء بنجاح، مشروعك الآن:
- ✅ يعمل محلياً
- ✅ جاهز للرفع
- ✅ بدون أخطاء

**الخطوة القادمة:** ارفع على GitHub! 🚀

---

**آخر تحديث:** 11 ديسمبر 2024
**الوقت المتوقع:** 5-10 دقائق
